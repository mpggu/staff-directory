# Staff-directory

This is a fork of the excellent WordPress plugin [https://wordpress.org/plugins/staff-directory/](Staff Directory). Please don't use this fork unless you know what you're doing.

## Plugin Features

- [staff-directory] shortcode with options for ordering, categories, etc
- Staff categories
- Ability to create custom staff details fields, complete with auto-generating shortcodes for custom fields
- 2 default templates for displaying staff
- Support for multiple templates. You can choose a default as well as choose set a template for use with the [staff-directory] shortcode.
